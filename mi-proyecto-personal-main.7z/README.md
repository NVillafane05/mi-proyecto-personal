# mi-proyecto-personal
reforzando los conocimientos de git
pryecto de prueba!!
